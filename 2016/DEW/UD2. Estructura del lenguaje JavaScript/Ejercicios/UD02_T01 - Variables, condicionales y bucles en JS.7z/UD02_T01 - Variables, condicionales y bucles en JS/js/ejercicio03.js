

function actividad03(numeroImagen){

  alert("Has hecho click sobre la imagen numero " + numeroImagen);
}
