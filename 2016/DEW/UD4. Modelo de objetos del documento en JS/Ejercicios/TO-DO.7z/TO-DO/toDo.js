//NO FUNCIONA
/*
function EliminarSeleccionados() {

    var contenedor = document.getElementById('myUL');
    var contenido = document.getElementById('myUL').innerHTML;
    if (contenido == null || contenido == " ") {
        alert("No hay valores a los que seleccionar");
    } else {
        var i = 0;
        var listahijos;
        var hijos = document.getElementById('myUL').childNodes;
        for (i = 0; i < hijos.length; i++) {

            listahijos = hijos[i];
            listahijos = listahijos.firstElementChild;
            if (listahijos.checked) {
                contenedor.removeChild(hijos[i]);
                contenedor.removeChild(hijos[i]);
                i = i - 2;
            }
        }
    }
}

*/


function eliminarSeleccionado() {
  var rmvCheckBoxes = document.getElementsByName('elementos');

    for(var i = 0; i < rmvCheckBoxes.length; i++)
    {
        if(rmvCheckBoxes[i].checked)
        {
            removeElm(rmvCheckBoxes[i]);
        }
    }
}

function removeElm(elm){
  var ext = elm.parentElement;
   ext.removeChild(elm);

}

//FUNCIONA
if (localStorage.getItem("contador") === null) {
    localStorage.setItem("contador", 0);
}

function newElement() {
    var li = document.createElement("li");
    var inputValue = document.getElementById("myInput").value;

    var checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.name = "elementos";
    checkbox.value = inputValue;
    var t = document.createTextNode(inputValue);

    li.appendChild(t);
    li.appendChild(checkbox);

    if (inputValue === '') {
        alert("Campo Vacío!");
    } else {
        document.getElementById("myUL").appendChild(li);
        guardarLocalStorage(inputValue);
    }
    document.getElementById("myInput").value = "";

}

function guardarLocalStorage(element) {
    var contador = localStorage.getItem("contador");
    var claveElemento = "Elemento" + contador;
    contador++;
    localStorage.setItem("contador", contador);
    localStorage.setItem(claveElemento, element);

}

function cargarLista() {

    for (var j = 0; j < localStorage.length; j++) {
        var claveComparar = "Elemento" + j;

        for (var i = 0; i < localStorage.length; i++) {
            var clave = localStorage.key(i);

            if (clave == claveComparar) {
                var li = document.createElement("li");
                var checkbox = document.createElement("input");
                checkbox.type = "checkbox";
                checkbox.name = "elementos";
                checkbox.value = localStorage.getItem(claveComparar);
                var t = document.createTextNode(localStorage.getItem(claveComparar));

                li.appendChild(t);
                li.appendChild(checkbox);
                document.getElementById("myUL").appendChild(li);
            }
        }
    }
}

function seleccionarTodo() {
  for (var i = 0; i < document.lista.elements.length; i++) {
    if (document.lista.elements[i].type=="checkbox") {
      document.lista.elements[i].checked=1;
    }
  }
}
function deseleccionarTodo() {
  for (var i = 0; i < document.lista.elements.length; i++) {
    if (document.lista.elements[i].type=="checkbox") {
      document.lista.elements[i].checked=0;
    }
  }
}
