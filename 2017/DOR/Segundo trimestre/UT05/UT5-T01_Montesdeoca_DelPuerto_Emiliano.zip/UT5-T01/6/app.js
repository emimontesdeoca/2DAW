function abrir() {
  var x = document.querySelectorAll(".mensaje");
  x[0].style.marginLeft = "0%";
}
function cerrar() {
  var x = document.querySelectorAll(".mensaje");
  x[0].style.marginLeft = "-100%";
}
