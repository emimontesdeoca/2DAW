/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.cifpcm.sakilajsf_emiliano.bean;

import es.cifpcm.sakilajsf_emiliano.pojo.Actor;
import java.util.List;

/**
 *
 * @author emont
 */
public interface ActorBeanInterface {

    public List<Actor> getActorList();
}
