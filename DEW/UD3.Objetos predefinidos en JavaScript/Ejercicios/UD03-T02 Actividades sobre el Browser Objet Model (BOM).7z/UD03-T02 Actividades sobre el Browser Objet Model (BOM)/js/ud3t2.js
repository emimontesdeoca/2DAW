//EJERCICIO1
function ejercicio1() {
    var textoFormato = "generado desde JS un texto con distinto formatos";
    var txt = "";
    txt += "<p>Enlace <a href='/'>" + textoFormato + "</a></p>";
    txt += "<p>Con un tamaño de fuente de 5px <span style='font-size:5px;'>" +
        textoFormato + "</span></p>";
    txt += "<p>Escribien superíndices <sup>" + textoFormato + "</sup></p>";
    txt += "<p>Escribien subíndices <sub>" + textoFormato + "</sub></p>";
    txt += "<p>Le damos formato cursiva <em>" + textoFormato + "</em></p>";
    txt += "<p>y por último, algo de color <span style='color:red;'>" + textoFormato + "</span></p>";
    txt += "<p>y por último, algo de color y en cursiva <em style='color:red;'>" + textoFormato + "</em></p>";
    document.getElementById("ejercicio1").innerHTML = txt;
}
//EJERCICIO2
function ejercicio2() {
    var fecha=new Date();
    var padreVentana = window.open();
    padreVentana.document.write('<html lang="es">' +
        '<head>' +
        '<script src="js/ud3t2.js"></script>'+
        '<title>JesúsManuelTorresBlanco</title>' +
        '</head>'+
        '<body>' +
          '<h1>Jesús Manuel</h1>'+
          '<h2>Torres</h2>'+
          '<h3>'+ fecha.getDate() + '/' + fecha.getMonth() + '/' + fecha.getFullYear()+'</h3>'+
          '<select>'+
            '<option>Tenerife</option>'+
            '<option>Gran Canaria</option>'+
            '<option>Lanzarote</option>'+
            '<option>Fuerteventura</option>'+
            '<option>Gomera</option>'+
            '<option>La Palma</option>'+
            '<option>Hierro</option>'+
        '</select>'+
        '<button type="button" onclick="abrirVentanaHija()">Abrir ventana Hija</button>' +
        '</body>' +
        '</html>');
}
function abrirVentanaHija() {
    var hijaVentana = window.open("", "Hija", "width=250,height=150");
    hijaVentana.document.write('<html lang="es">' +
        '<head>' +
        '<title>VentanaTEST</title>' +
        '</head>' +
        '<body onunload= "opener.location.href=\'http://www.elpais.com\'"">' +
        '<p>Nueva</p>' +
        '</body>' +
        '</html>');
}

//EJERICIO3
function ejercicio3() {
  var color=document.getElementById("ej3Color").value;
  if (esHex(color)) {
 document.bgColor=color;
  } else {
  window.alert("Introduzca un color con formato Hexadecimal: (#000000 - #FFFFFF)");
  }
}
function esHex(h) {
  var re = /^#[0-9A-Fa-f]{6}$/g; //Empieza por # y le siguen 6 digitos entre [0-9] y[a-f]
  if(re.test(h)) {
      return true;
  } else {
    return false;
  }
  re.lastIndex = 0;
}


function ejercicio4() {
  var ej4Ventana= window.open();
  ej4Ventana.document.write('<html lang="es">' +
      '<head>' +
      '<script src="js/ud3t2.js">'+
      setInterval(function() {
                              document.getElementById('Nombre').style.color= crearColorHexa();
                              },5000);'</script>'+
      '<title>CambiarColor</title>' +
      '</head>' +
      '<body onload="cambiarColor">' +
      '<h1 id="Nombre">Jesús</h1>' +
      <script></script>
      '</body>' +
      '</html>');

}
function cambiarColor() {


}

function crearColorHexa() {
    hexadecimal = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F");
    color_aleatorio = "#";
    for (i = 0; i < 6; i++) {
        posarray = aleatorio(0, hexadecimal.length);
        color_aleatorio += hexadecimal[posarray];
    }
    return color_aleatorio;
}
