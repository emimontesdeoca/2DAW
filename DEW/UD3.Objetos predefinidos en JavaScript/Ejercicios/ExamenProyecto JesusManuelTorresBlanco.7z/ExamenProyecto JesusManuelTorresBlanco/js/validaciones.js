function isNumero(numero) {
    if (isNaN(numero)) {
        console.log(numero + " NO es un numero entero");
        return false;
    } else {
        console.log(numero + " es un numero entero");
        return true;
    }

}

function isEntero(numero) {
    if (numero % 1 === 0) {
        console.log(numero + " es un numero entero");
        return true;
    } else {
        console.log(numero + " NO es un numero entero");
        return false;
    }
}

function isFechaDDMMAAAA(fecha) {
    var dtCh = "/";
    var minYear = 1900;
    var maxYear = 2100;

    function isInteger(s) {
        var i;
        for (i = 0; i < s.length; i++) {
            var c = s.charAt(i);
            if (((c < "0") || (c > "9"))) return false;
        }
        return true;
    }

    function stripCharsInBag(s, bag) {
        var i;
        var returnString = "";
        for (i = 0; i < s.length; i++) {
            var c = s.charAt(i);
            if (bag.indexOf(c) == -1) returnString += c;
        }
        return returnString;
    }

    function daysInFebruary(year) {
        return (((year % 4 === 0) && (((year % 100 !== 0)) || (year % 400 === 0))) ? 29 : 28);
    }

    function DaysArray(n) {
        for (var i = 1; i <= n; i++) {
            this[i] = 31;
            if (i === 4 || i === 6 || i === 9 || i === 11) {
                this[i] = 30;
            }
            if (i === 2) {
                this[i] = 29;
            }
        }
        return this;
    }

    function isDate(dtStr) {
        var daysInMonth = DaysArray(12);
        var pos1 = dtStr.indexOf(dtCh);
        var pos2 = dtStr.indexOf(dtCh, pos1 + 1);
        var strDay = dtStr.substring(0, pos1);
        var strMonth = dtStr.substring(pos1 + 1, pos2);
        var strYear = dtStr.substring(pos2 + 1);
        strYr = strYear;
        if (strDay.charAt(0) == "0" && strDay.length > 1) strDay = strDay.substring(1);
        if (strMonth.charAt(0) == "0" && strMonth.length > 1) strMonth = strMonth.substring(1);
        for (var i = 1; i <= 3; i++) {
            if (strYr.charAt(0) == "0" && strYr.length > 1) strYr = strYr.substring(1);
        }
        month = parseInt(strMonth);
        day = parseInt(strDay);
        year = parseInt(strYr);
        if (pos1 == -1 || pos2 == -1) {
            return false;
        }
        if (strMonth.length < 1 || month < 1 || month > 12) {
            return false;
        }
        if (strDay.length < 1 || day < 1 || day > 31 || (month == 2 && day > daysInFebruary(year)) || day > daysInMonth[month]) {
            return false;
        }
        if (strYear.length != 4 || year === 0 || year < minYear || year > maxYear) {
            return false;
        }
        if (dtStr.indexOf(dtCh, pos2 + 1) != -1 || isInteger(stripCharsInBag(dtStr, dtCh)) === false) {
            return false;
        }
        return true;
    }
    if (isDate(fecha)) {
        return true;
    } else {
        return false;
    }
}

function isEmail(valor) {
    if (!(/\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)/.test(valor))) {
        console.log("NO es un Email");
        return false;
    } else {
        console.log("Es un Email");
        return true;
    }
}

function isHex(h) {
    var re = /^#[0-9A-Fa-f]{6}$/g; //Empieza por # y le siguen 6 digitos entre [0-9] y[a-f]
    if (re.test(h)) {
        return true;
    } else {
        return false;
    }
    re.lastIndex = 0;
}
