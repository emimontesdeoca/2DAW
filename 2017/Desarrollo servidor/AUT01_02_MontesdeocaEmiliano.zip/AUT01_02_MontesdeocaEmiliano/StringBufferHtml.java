package stringbufferhtml;

import java.util.Scanner;

/**
 *
 * @author Emiliano Montesdeoca del Puerto
 */
public class StringBufferHtml {
public static void main(String[] args) {
        /// Carpeta TEMP
        String tempFolder = System.getenv("TEMP");
        /// Nombre de fichero
        String fileName = "\\hola.html";
        
        /// Preguntar por valores
        String title = askString("Titulo de la pagina: ");
        String name = askString("Introduce nombre: ");
        
        /// Crear archivo
        FileCreator.createFile(tempFolder + fileName, createHtml(title,name));
    }

    public static String askString(String text){
        /// Muestra texto
        System.out.printf(text);
        /// Devuelve respuesta
        return new Scanner(System.in).next();
    }
    
    public static String createHtml(String title, String name) {
        /// Objeto StringBuffer
        StringBuffer sb = new StringBuffer();
        /// Creando el Html
        sb.append("<html>");
        sb.append("<head>");
        sb.append("<title>" + title + "</title>");
        sb.append("</head>");
        sb.append("<body>");
        sb.append("<h1>" + "Hola: " + name + "</h1>");
        sb.append("</body>");
        sb.append("</html>");
        /// Retornar el string
        return sb.toString();
    }
     
    }